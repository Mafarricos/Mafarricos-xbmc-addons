service.autosubs
===============

Auto run XBMC Subtitles if no subs are found for a Movie/TV Show.<br>
Exclude media paths that include certain words that could trigger the script in addon settings.

Note:<br>
Some additional configuration settings that can be done in XBMC Subtitles to reduce end-user actions are:<br>
Enable the following in Advanced Options for XBMC Subtitles.
- Search next available service if no results are found
- Auto download first " sync" subtitle
