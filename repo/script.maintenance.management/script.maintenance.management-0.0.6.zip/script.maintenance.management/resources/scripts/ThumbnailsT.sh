#!/bin/bash
du /*/.xbmc/userdata/Thumbnails/ -sh && du /*/.xbmc/userdata/Database/Textures13.db -sh