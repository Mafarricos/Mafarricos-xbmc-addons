#!/bin/bash
rm -rfv /*/.xbmc/addons/packages/*