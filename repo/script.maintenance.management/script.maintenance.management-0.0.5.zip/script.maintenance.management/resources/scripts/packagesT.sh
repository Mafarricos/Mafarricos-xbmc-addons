#!/bin/bash
du /*/.xbmc/addons/packages/ -sh