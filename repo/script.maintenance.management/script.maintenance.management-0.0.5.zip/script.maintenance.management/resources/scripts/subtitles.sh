#!/bin/bash
rm -rfv /*/.xbmc/userdata/addon_data/service.subtitles.*/temp