#!/bin/bash
du /*/.xbmc/userdata/addon_data/script.module.metahandler/meta_cache/ -sh