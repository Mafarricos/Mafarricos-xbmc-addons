#!/bin/bash
rm -rfv /*/.xbmc/temp/*