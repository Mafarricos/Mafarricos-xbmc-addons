#!/bin/bash
du /*/.xbmc/userdata/addon_data/service.subtitles.*/temp/ -sh