#!/bin/bash
rm -rfv /*/.xbmc/userdata/addon_data/script.module.metahandler/meta_cache