#!/bin/bash
rm -rfv /*/.xbmc/userdata/Thumbnails/* && rm -r /*/.xbmc/userdata/Database/Textures13.db