#!/bin/bash
du /*/.xbmc/temp/ -sh