#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# by Mafarricos
# email: MafaStudios@gmail.com
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


##############BIBLIOTECAS A IMPORTAR E DEFINICOES####################

import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,HTMLParser
#CMC0.0.3,sn
import socket
from urllib2 import urlopen, URLError, HTTPError
socket.setdefaulttimeout( 23 )  # timeout in seconds
#CMC0.0.3,en
h = HTMLParser.HTMLParser()

addon_id = 'plugin.video.ogatodasbotas'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = '/resources/img/'
siteurl = 'http://videos.ogatodasbotas.com/'
user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:10.0a1) Gecko/20111029 Firefox/10.0a1'

################################################## 
#MENUS

def CATEGORIES():
	#CMC0.0.3,sn
	try :
		req = urllib2.Request(siteurl)
		req.add_header('User-Agent', user_agent)
		response = urllib2.urlopen(req)	
		#response = urlopen( siteurl )
	except HTTPError, e:
		addDir(str(e.code),siteurl,1,'http://digitalsherpa.com/wp-content/uploads/2013/04/social-media-marketing-tool.png',False)
		print 'The server couldn\'t fulfill the request. Reason:', str(e.code)
	except URLError, e:
		addDir(str(e.reason),siteurl,1,'http://digitalsherpa.com/wp-content/uploads/2013/04/social-media-marketing-tool.png',False)
		print 'We failed to reach a server. Reason:', str(e.reason)
	else :
	#CMC0.0.3,en
		addDir('Top',siteurl,1,'http://digitalsherpa.com/wp-content/uploads/2013/04/social-media-marketing-tool.png',True)
		addDir('Desenhos Animados (Anos 70)',siteurl+'/category/desenhos-animados/anos-70/',4,'http://digitalsherpa.com/wp-content/uploads/2013/04/social-media-marketing-tool.png',True)		
		addDir('Desenhos Animados (Anos 80)',siteurl+'/category/desenhos-animados/anos-80/',4,'http://digitalsherpa.com/wp-content/uploads/2013/04/social-media-marketing-tool.png',True)		
		addDir('Desenhos Animados (Anos 90)',siteurl+'/category/desenhos-animados/anos-90/',4,'http://digitalsherpa.com/wp-content/uploads/2013/04/social-media-marketing-tool.png',True)		
		addDir('Música',siteurl+'category/musicas/',4,'http://digitalsherpa.com/wp-content/uploads/2013/04/social-media-marketing-tool.png',True)
		addDir('Cinema',siteurl+'category/cinema/',4,'http://digitalsherpa.com/wp-content/uploads/2013/04/social-media-marketing-tool.png',True)	
		addDir('Programas TV',siteurl+'category/programas-tv/',4,'http://digitalsherpa.com/wp-content/uploads/2013/04/social-media-marketing-tool.png',True)	
		
##################################################
#FUNCOES
			
def listar_videos(url):
	codigo_fonte = abrir_url(url)	
	addDir('[COLOR yellow]Inicio[/COLOR]','',0,'',True)			
	print codigo_fonte
	match = re.compile('" href="(.+?)" title=".+?"><img src=".+?" width="\d+" height="\d+" alt="" /> </a>\s+</figure>\s+</div>\s+<h1 class="title">(.+?)</h1>\s+<p></p>\s+<footer class="aligncenter">\s+<a href="(.+?)" class="button medium button-style1">Ver</a>').findall(codigo_fonte)
	for img,titulo,url in match:
		titulo = subststring(titulo)	
		#titulo,url = encontrar_tipo_da_fonte(url,titulo)	
		addDir(titulo,url,2,img,False)

def listar_videos_category(url):
	codigo_fonte = abrir_url(url)	
	addDir('[COLOR yellow]Inicio[/COLOR]','',0,'',True)			
	print codigo_fonte
	match = re.compile('<h1><a href="(.+?)">(.+?)</a></h1>\s+</div><!--/ post-title-->\s+<div class="border-shadow alignleft">\s+<figure>\s+<a class="prettyPhoto" title=".+?" href="(.+?)">').findall(codigo_fonte)
	for url,titulo,img in match:
		titulo = subststring(titulo)
		#titulo,url = encontrar_tipo_da_fonte(url,titulo)	
		addDir(titulo,url,2,img,False)
	match = re.compile('<link rel="next" href="(.+?)" />').findall(codigo_fonte)	
	if match:
		nexturl = match[0]
		addDir('[COLOR yellow]Proximo >>[/COLOR]',nexturl,4,'',True)
		addDir('[COLOR yellow]Inicio[/COLOR]','',0,'',True)				

#CMC0.0.3,sn
def encontrar_tipo_da_fonte(url):
	codigo_fonte = abrir_url(url)
	match = re.compile('youtube.com/embed/(.+?)"').findall(codigo_fonte)
	if match:
		print "@@DEBUG: YOUTUBE"	
		return 'plugin://plugin.video.youtube/?action=play_video&videoid='+match[0]
	return 'NOTSUPPORT'
		
def subststring(titulo):
	titulo = titulo.replace('&#8211;', '-')	
	titulo = titulo.replace('&#038;', 'e')
	return titulo

def play(url):
  url=encontrar_tipo_da_fonte(url)
  print '@@DEBUG '+url
  listitem = xbmcgui.ListItem()
  listitem.setPath(url)
  listitem.setProperty('mimetype', 'video/x-msvideo')
  listitem.setProperty('IsPlayable', 'true')
  try:
	xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
	xbmcPlayer.play(url)
  except:
   pass
   #self.message("Couldn't play item.")
			
#####################################################
#FUNCOES JÁ FEITAS

def abrir_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', user_agent)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def addDir(name,url,mode,iconimage,pasta):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta)
        return ok
		
##############################
#GET PARAMS

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

      
params=get_params()
url=None
name=None
mode=None
iconimage=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

try:        
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Iconimage: "+str(iconimage)

#################################
#MODOS

if mode==None or url==None or len(url)<1: CATEGORIES()
elif mode==1: listar_videos(url)
elif mode==2: play(url)
elif mode==4: listar_videos_category(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))